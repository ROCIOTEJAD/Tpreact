import { FC } from "react"

interface IPropsMIPrimerComponent{
    text:string
    color: string

}


export const MiPrimerComponent : 
FC<IPropsMIPrimerComponent> = ({
    text, color,}) => {
    return ( 
    <div style={{color: `${color}`}}> <p>{text}</p> </div>
  )
}
