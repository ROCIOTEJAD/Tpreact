import React, { FC } from 'react';
import { Button, Form } from 'react-bootstrap';
import { useForm } from './useForm';

interface IPropsFormProduct {
  handleAddProduct: (newItem: { nombre: string; imagen: string; precio: number }) => void;
}

export const FormProduct: FC<IPropsFormProduct> = ({ handleAddProduct }) => {
  const { handleChange, value, resetForm } = useForm({
    nombre: '',
    imagen: '',
    precio: 0,
  });

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    handleAddProduct(value);
    resetForm();
  };

  return (
    <Form className="p-4 border rounded m-3" onSubmit={handleSubmitForm}>
      <Form.Group controlId="formNombre">
        <Form.Label>Nombre</Form.Label>
        <Form.Control
          type="text"
          name="nombre"
          placeholder="Ingrese nombre producto"
          value={value.nombre}
          onChange={handleChange}
        />
      </Form.Group>
      <Form.Group controlId="formImagen">
        <Form.Label>Imagen</Form.Label>
        <Form.Control
          type="text"
          name="imagen"
          placeholder="Ingrese imagen del producto"
          value={value.imagen}
          onChange={handleChange}
        />
      </Form.Group>
      <Form.Group controlId="formPrecio">
        <Form.Label>Precio</Form.Label>
        <Form.Control
          type="number"
          name="precio"
          placeholder="Ingrese precio del producto"
          value={value.precio}
          onChange={handleChange}
        />
      </Form.Group>
      <div className="d-flex justify-content-center mt-4">
        <Button type="submit" variant="primary">
          Enviar Producto
        </Button>
      </div>
    </Form>
  );
};

