import { AppProduct } from "./components/AppProduct/AppProduct";


export const App = () => {
   
  return (
    <div style={{ display:"flex", flexDirection: "column"}}>
      {/* <MiPrimerComponent text="Texto desde propiedades" color="red" />
      
    <ComponentCounter />
     
      <ComponentUseEffect /> 
      <FormComponent />*/}
      <AppProduct/>
    </ div>
  );
};

